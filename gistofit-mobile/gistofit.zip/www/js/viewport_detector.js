	(function() {
		// Create the ViewPort detector
	})();
