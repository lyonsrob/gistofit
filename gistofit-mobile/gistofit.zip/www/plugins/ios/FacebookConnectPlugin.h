//
//  FacebookConnectPlugin.h
//  GapFacebookConnect
//
//  Created by Jesse MacFadyen on 11-04-22.
//  Copyright 2011 Nitobi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FacebookSDK.h"

#import <Cordova/CDV.h>

@interface FacebookConnectPlugin : CDVPlugin {
}

@end
